require "merge_excel/version"

module MergeExcel
  # Your code goes here...
end
